Left Click to switch avatars

Both avatars use WASD controls.

Kid:

W pedal forward
A turn left
S pedal backward
D turn right

SPACE jump

Kaiju:

Tap A: Slide to clockwise cover
Tap D: Slide to counter clockwise cover

Hold / Release A: Leap to far left cover (adjacently across streets)
Hold / Release D: Leap to far right cover (adjacently across streets)
Hold / Release S: Leap to far back cover (behind across street)